import type { BffCredential, BffTarget } from "@yueli/nuxt-runtime/server";

export function assetBffTarget(base: string): BffTarget {
  const url = new URL(base);
  if (
    (url.protocol !== "http:" && url.protocol !== "https:") ||
    url.username ||
    url.password ||
    url.search ||
    url.hash
  ) {
    throw new TypeError("Invalid private BFF target");
  }
  const pathPrefix =
    url.pathname === "/" ? undefined : url.pathname.replace(/\/$/, "");
  return { origin: url.origin, ...(pathPrefix ? { pathPrefix } : {}) };
}

// Public media keeps its stable browser-facing `/media` interface while this
// adapter explicitly selects Asset's v1 implementation interface. A future v2
// can coexist without changing consumer URLs.
export function assetMediaBffTarget(base: string): BffTarget {
  const target = assetBffTarget(base);
  return {
    origin: target.origin,
    pathPrefix: `${target.pathPrefix || ""}/api/v1/media`,
  };
}

export function assetFileBffTarget(base: string): BffTarget {
  const target = assetBffTarget(base);
  return {
    origin: target.origin,
    pathPrefix: `${target.pathPrefix || ""}/files`,
  };
}

export function assetBffCredential(
  headers: Readonly<Record<string, string>>,
): BffCredential {
  const authorization = headers.authorization;
  return authorization?.startsWith("Bearer ")
    ? { kind: "bearer", token: authorization.slice("Bearer ".length) }
    : { kind: "anonymous" };
}
