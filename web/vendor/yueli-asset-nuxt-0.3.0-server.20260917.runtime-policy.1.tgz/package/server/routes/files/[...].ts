import { createBffHandler } from "@yueli/nuxt-runtime/server";

export default createBffHandler({
  mountPath: "/files",
  profile: "asset",
  timeoutMs: 60_000,
  resolveTarget({ event }) {
    return assetFileBffTarget(String(useRuntimeConfig(event).assetBase));
  },
});
