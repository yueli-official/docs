import { createBffHandler } from "@yueli/nuxt-runtime/server";

export default createBffHandler({
  mountPath: "/media",
  profile: "asset",
  timeoutMs: 60_000,
  resolveTarget({ event }) {
    return assetMediaBffTarget(String(useRuntimeConfig(event).assetBase));
  },
});
