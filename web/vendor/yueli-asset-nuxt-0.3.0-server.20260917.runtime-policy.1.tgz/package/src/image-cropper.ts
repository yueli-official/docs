import {
  createCropperJsConfig,
  createCropperOutputOptions,
  type CropperConfigInput,
  type CropperOutputInput,
} from "@yueli/ui/image";

export {
  cropFilename as filenameForCrop,
  extensionForCrop,
  normalizeCropMode,
} from "@yueli/ui/image";

export function buildPictureCropperConfig(input: CropperConfigInput) {
  const config = createCropperJsConfig(input);
  if (input.mode !== "free" || input.shape === "circle") return config;
  return {
    ...config,
    options: { ...config.options, autoCropArea: 1 },
  };
}
export type {
  CropMode as AssetCropMode,
  CropOutputType as AssetCropOutputType,
  CropShape as AssetCropShape,
  CropperConfigInput as AssetCropperConfigInput,
  CropperJsConfig as PictureCropperConfig,
} from "@yueli/ui/image";

export interface AssetCropperOutputInput extends CropperOutputInput {
  /** Encoding quality remains consumed by the visual cropper's Blob step. */
  quality?: number;
}

export function cropperOutputOptions(input: AssetCropperOutputInput) {
  return createCropperOutputOptions(input);
}

export function calculateCropCanvasSize(
  crop: { width: number; height: number },
  bounds: { width?: number; height?: number } = {},
) {
  const width = Number.isFinite(crop.width) && crop.width > 0 ? crop.width : 1;
  const height = Number.isFinite(crop.height) && crop.height > 0 ? crop.height : 1;
  const maxWidth = bounds.width !== undefined && Number.isFinite(bounds.width) && bounds.width > 0
    ? bounds.width
    : width;
  const maxHeight = bounds.height !== undefined && Number.isFinite(bounds.height) && bounds.height > 0
    ? bounds.height
    : height;
  const scale = Math.min(1, maxWidth / width, maxHeight / height);
  return {
    width: Math.max(1, Math.round(width * scale)),
    height: Math.max(1, Math.round(height * scale)),
  };
}
