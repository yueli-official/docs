const BASE62_ALPHABET =
  "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
const UUID_RE =
  /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
// API-provided keys are opaque to consumers. The current server emits a
// canonical Base62 UUID encoding, while this broader Base64URL-safe envelope
// lets the server move to independent random keys without another client API.
const MEDIA_KEY_RE = /^[0-9A-Za-z_-]{1,64}$/;
const RENDITION_RE = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;

export type AssetMediaFormat = "jpg" | "png" | "webp";

export interface AssetMediaReference {
  id?: string;
  mediaKey?: string;
}

export interface AssetMediaURLOptions {
  base?: string;
  format?: AssetMediaFormat;
  version?: number;
}

export interface AssetFileURLOptions {
  base?: string;
}

export function assetMediaKey(
  reference: string | AssetMediaReference,
): string {
  if (typeof reference !== "string" && reference.mediaKey) {
    if (!MEDIA_KEY_RE.test(reference.mediaKey))
      throw new TypeError("Invalid asset media key");
    return reference.mediaKey;
  }

  const assetID =
    typeof reference === "string" ? reference : reference.id || "";
  if (!UUID_RE.test(assetID)) throw new TypeError("Invalid asset UUID");

  let value = BigInt(`0x${assetID.replaceAll("-", "")}`);
  if (value === 0n) return "0";
  let key = "";
  while (value > 0n) {
    key = BASE62_ALPHABET[Number(value % 62n)] + key;
    value /= 62n;
  }
  return key;
}

export function assetFileUrl(
  reference: string | AssetMediaReference,
  options: AssetFileURLOptions = {},
): string {
  const rawBase = options.base ?? "";
  if (rawBase.includes("?") || rawBase.includes("#"))
    throw new TypeError("Invalid file base URL");
  const base = rawBase.replace(/\/+$/, "");
  return `${base}/files/${assetMediaKey(reference)}`;
}

export function assetMediaUrl(
  reference: string | AssetMediaReference,
  rendition: string,
  options: AssetMediaURLOptions = {},
): string {
  const name = rendition.toLowerCase();
  if (name.length > 64 || !RENDITION_RE.test(name))
    throw new TypeError("Invalid media rendition");

  const format = (options.format || "webp").toLowerCase();
  if (format !== "jpg" && format !== "png" && format !== "webp")
    throw new TypeError("Unsupported media format");

  const rawBase = options.base ?? "";
  if (rawBase.includes("?") || rawBase.includes("#"))
    throw new TypeError("Invalid media base URL");
  const base = rawBase.replace(/\/+$/, "");
  const key = assetMediaKey(reference);
  const version = options.version ?? 1;
  if (!Number.isSafeInteger(version) || version < 1)
    throw new TypeError("Invalid media delivery version");
  return `${base}/media/${key}?format=${format}&preset=${name}&v=${version}`;
}
