export interface AssetReferenceLifecycle {
  complete: boolean;
  strategy: "snapshot" | "outbox" | "direct" | "none";
  coverage: string;
}

export type AssetRegistrationStatus = "accepted" | "pending" | "rejected";

export interface AssetRegistrationVariant {
  key: string;
  width: number;
  height: number;
  mode: string;
  format: string;
  quality: number;
  visibility: "public" | "private";
  metadataPolicy: "strip" | "preserve";
  presets: AssetVariantPresetOption[];
}

export interface AssetRegistrationProfile {
  key: string;
  kind: "public-image" | "private-original" | "public-file" | "private-file";
  purpose: string;
  allowedMimes: string[];
  maxBytes: number;
  maxPixels: number;
  visibility: "public" | "private";
  metadataPolicy: "strip" | "preserve";
  keepOriginal: boolean;
  storageClass: string;
  selectedStorageBackend?: string;
  storageBackend?: string;
  variants: AssetRegistrationVariant[];
}

export interface AssetRegistrationView {
  consumerKey: string;
  namespaceKey: string;
  revision: number;
  declarationDigest: string;
  effectiveDigest: string;
  effective: {
    consumerKey: string;
    namespaceKey: string;
    displayName: string;
    referenceLifecycle?: AssetReferenceLifecycle;
    profiles: AssetRegistrationProfile[];
  };
}

export interface AssetRegistrationApplicationView {
  consumerKey: string;
  revision: number;
  declarationDigest: string;
  declaration: {
    consumerKey: string;
    namespaceKey: string;
    displayName: string;
    referenceLifecycle?: AssetReferenceLifecycle;
    profiles: AssetRegistrationProfile[];
  };
  status: AssetRegistrationStatus;
  findings: Array<{ code: string; path: string }>;
  submittedBy: string;
}

export interface AssetRegistrationStateView {
  consumerKey: string;
  registration?: AssetRegistrationView;
  applications: AssetRegistrationApplicationView[];
}

export interface AssetConsumerSettingsProfile {
  key: string;
  allowedMimes: string[];
  maxBytes: number;
  storageBackend: string;
  variants: Array<{
    key: string;
    preset: string;
  }>;
}

export interface AssetStorageBackendOption {
  name: string;
  type: string;
  available: boolean;
}

export interface AssetProfileStorageBackendOptions {
  profileKey: string;
  items: AssetStorageBackendOption[];
}

export interface AssetProfilePolicyOptions {
  profileKey: string;
  allowedMimes: string[];
  maxBytes: number;
}

export interface AssetRegistrationResponse {
  state: AssetRegistrationStateView;
  storageBackends: AssetProfileStorageBackendOptions[];
  profileOptions: AssetProfilePolicyOptions[];
}

export interface AssetVariantPresetOption {
  key: string;
  width: number;
  height: number;
  mode: "fill" | "resize" | "resize-width";
  format: "jpeg" | "png" | "webp";
  quality: number;
}

export interface AssetVariantSlotDefinition {
  profileKey: string;
  key: string;
  label: string;
  usage: string;
  presetLabels: Record<string, string>;
}

export interface AssetConsumerSettingsUpdateResponse {
  state: AssetRegistrationStateView;
  application: AssetRegistrationApplicationView;
  storageBackends: AssetProfileStorageBackendOptions[];
  profileOptions: AssetProfilePolicyOptions[];
}

export function formatRegistrationBytes(bytes: number) {
  if (!Number.isFinite(bytes) || bytes <= 0) return "未限制";
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`;
  if (bytes < 1024 * 1024 * 1024)
    return `${Number((bytes / 1024 / 1024).toFixed(1))} MB`;
  return `${Number((bytes / 1024 / 1024 / 1024).toFixed(1))} GB`;
}

export function registrationKindLabel(kind: AssetRegistrationProfile["kind"]) {
  return {
    "public-image": "公开图片",
    "private-original": "私有原件",
    "public-file": "公开文件",
    "private-file": "私有文件",
  }[kind];
}
