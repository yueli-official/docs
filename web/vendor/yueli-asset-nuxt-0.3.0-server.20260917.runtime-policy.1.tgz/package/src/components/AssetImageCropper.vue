<script setup lang="ts">
import Cropper from 'cropperjs'
import 'cropperjs/dist/cropper.css'
import {
  buildPictureCropperConfig,
  calculateCropCanvasSize,
  filenameForCrop,
  type AssetCropMode,
  type AssetCropOutputType,
  type AssetCropShape
} from '../image-cropper'

interface CropCoordinates {
  left: number
  top: number
  width: number
  height: number
}

interface CroppedPayload {
  file: File
  blob: Blob
  coordinates: CropCoordinates
  source: {
    width: number
    height: number
  }
  outputSize: {
    width: number
    height: number
  }
}

const props = withDefaults(defineProps<{
  open?: boolean
  file?: File | null
  title?: string
  shape?: AssetCropShape
  mode?: AssetCropMode
  aspectRatio?: number
  outputWidth?: number
  outputHeight?: number
  outputType?: AssetCropOutputType
  quality?: number
  minSourceWidth?: number
  minSourceHeight?: number
  maxSourceWidth?: number
  maxSourceHeight?: number
  minCropWidth?: number
  minCropHeight?: number
  maxCropWidth?: number
  maxCropHeight?: number
  confirmLabel?: string
}>(), {
  open: false,
  file: null,
  title: '裁剪图片',
  shape: 'rect',
  mode: 'fixed',
  aspectRatio: 3 / 2,
  outputWidth: undefined,
  outputHeight: undefined,
  outputType: 'image/webp',
  quality: 0.9,
  minSourceWidth: undefined,
  minSourceHeight: undefined,
  maxSourceWidth: undefined,
  maxSourceHeight: undefined,
  minCropWidth: undefined,
  minCropHeight: undefined,
  maxCropWidth: undefined,
  maxCropHeight: undefined,
  confirmLabel: '使用裁剪图'
})

const emit = defineEmits<{
  'update:open': [value: boolean]
  cropped: [payload: CroppedPayload]
  cancel: []
  error: [message: string]
}>()

const imageElement = ref<HTMLImageElement | null>(null)
const imageUrl = ref('')
const sourceSize = ref<{ width: number, height: number } | null>(null)
const localError = ref('')
const processing = ref(false)
const loading = ref(false)
const cropperReady = ref(false)
const cropperInstance = shallowRef<Cropper | null>(null)
const zoomPercent = ref(100)
const currentCrop = ref<CropCoordinates | null>(null)

const ZOOM_MIN = 100
const ZOOM_MAX = 400
const ZOOM_STEP = 10

const localOpen = computed({
  get: () => props.open,
  set: value => emit('update:open', value)
})

const cropperConfig = computed(() => buildPictureCropperConfig({
  shape: props.shape,
  mode: props.mode,
  aspectRatio: props.aspectRatio,
  outputWidth: props.outputWidth,
  outputHeight: props.outputHeight,
  minCropWidth: props.minCropWidth,
  minCropHeight: props.minCropHeight
}))

const cropperKey = computed(() => [
  props.shape,
  props.mode,
  props.aspectRatio || 0
].join(':'))

const canConfirm = computed(() => Boolean(
  imageUrl.value &&
  getCropper() &&
  cropperReady.value &&
  !localError.value &&
  !loading.value &&
  !processing.value
))
const currentOutputSize = computed(() => currentCrop.value ? outputCanvasSize(currentCrop.value) : null)

let objectUrl = ''
let currentFile: File | null = null
let sourceImage: HTMLImageElement | null = null
let initializedCropperKey = ''
let loadToken = 0
let baseCanvasRatio = 1

function destroyCropper() {
  cropperInstance.value?.destroy()
  cropperInstance.value = null
  initializedCropperKey = ''
  cropperReady.value = false
  zoomPercent.value = 100
  currentCrop.value = null
  baseCanvasRatio = 1
}

function cleanupObjectUrl() {
  loadToken += 1
  destroyCropper()
  imageUrl.value = ''
  currentFile = null
  sourceImage = null
  if (objectUrl) {
    URL.revokeObjectURL(objectUrl)
    objectUrl = ''
  }
}

function initializeCropper() {
  const nextKey = `${imageUrl.value}:${cropperKey.value}`
  if (initializedCropperKey === nextKey) return
  destroyCropper()
  if (!imageElement.value) return
  initializedCropperKey = nextKey
  try {
    cropperInstance.value = new Cropper(imageElement.value, {
      ...cropperConfig.value.options,
      ready: () => {
        const cropper = getCropper()
        if (!cropper) return
        const canvas = cropper.getCanvasData()
        baseCanvasRatio = canvas.naturalWidth > 0 ? canvas.width / canvas.naturalWidth : 1
        zoomPercent.value = 100
        cropperReady.value = true
      },
      zoom: (event) => {
        const nextPercent = (event.detail.ratio / baseCanvasRatio) * 100
        if (nextPercent < ZOOM_MIN - 0.5 || nextPercent > ZOOM_MAX + 0.5) {
          event.preventDefault()
          return
        }
        zoomPercent.value = Math.round(nextPercent)
      },
      crop: (event) => {
        currentCrop.value = {
          left: event.detail.x,
          top: event.detail.y,
          width: event.detail.width,
          height: event.detail.height
        }
      }
    })
  } catch (error) {
    initializedCropperKey = ''
    throw error
  }
}

function validateSource(width: number, height: number) {
  if (props.minSourceWidth && width < props.minSourceWidth) return `原图宽度不能小于 ${props.minSourceWidth}px`
  if (props.minSourceHeight && height < props.minSourceHeight) return `原图高度不能小于 ${props.minSourceHeight}px`
  if (props.maxSourceWidth && width > props.maxSourceWidth) return `原图宽度不能大于 ${props.maxSourceWidth}px`
  if (props.maxSourceHeight && height > props.maxSourceHeight) return `原图高度不能大于 ${props.maxSourceHeight}px`
  return ''
}

function validateCrop(coordinates?: CropCoordinates | null) {
  if (!coordinates) return ''
  if (![coordinates.left, coordinates.top, coordinates.width, coordinates.height].every(Number.isFinite)
    || coordinates.width <= 0
    || coordinates.height <= 0) return '裁剪区域尚未准备好，请稍后重试'
  if (props.minCropWidth && coordinates.width < props.minCropWidth) return `裁剪宽度不能小于 ${props.minCropWidth}px`
  if (props.minCropHeight && coordinates.height < props.minCropHeight) return `裁剪高度不能小于 ${props.minCropHeight}px`
  if (props.maxCropWidth && coordinates.width > props.maxCropWidth) return `裁剪宽度不能大于 ${props.maxCropWidth}px`
  if (props.maxCropHeight && coordinates.height > props.maxCropHeight) return `裁剪高度不能大于 ${props.maxCropHeight}px`
  return ''
}

function prepareFile(file: File | null | undefined) {
  if (!file) {
    cleanupObjectUrl()
    sourceSize.value = null
    localError.value = ''
    loading.value = false
    return
  }

  if (currentFile === file && imageUrl.value) return

  cleanupObjectUrl()
  localError.value = ''
  loading.value = true

  const token = loadToken
  const nextUrl = URL.createObjectURL(file)
  const img = new Image()

  img.onload = () => {
    if (token !== loadToken) {
      URL.revokeObjectURL(nextUrl)
      return
    }

    const message = validateSource(img.naturalWidth, img.naturalHeight)
    if (message) {
      URL.revokeObjectURL(nextUrl)
      sourceSize.value = { width: img.naturalWidth, height: img.naturalHeight }
      localError.value = message
      loading.value = false
      emit('error', message)
      return
    }

    objectUrl = nextUrl
    currentFile = file
    sourceImage = img
    sourceSize.value = { width: img.naturalWidth, height: img.naturalHeight }
    imageUrl.value = nextUrl
    loading.value = false
  }

  img.onerror = () => {
    if (token !== loadToken) {
      URL.revokeObjectURL(nextUrl)
      return
    }
    URL.revokeObjectURL(nextUrl)
    localError.value = '图片加载失败'
    loading.value = false
    emit('error', localError.value)
  }

  img.src = nextUrl
}

function getCropper() {
  return cropperInstance.value
}

function cropCoordinates(cropper: Cropper): CropCoordinates {
  const data = cropper.getData(true)
  return {
    left: data.x,
    top: data.y,
    width: data.width,
    height: data.height
  }
}

function blobFromCanvas(canvas: HTMLCanvasElement) {
  const dataUrl = canvas.toDataURL(props.outputType, props.quality)
  const match = /^data:([^;,]+);base64,(.*)$/u.exec(dataUrl)
  if (!match) return null
  const binary = atob(match[2]!)
  const bytes = new Uint8Array(binary.length)
  for (let index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index)
  return new Blob([bytes], { type: match[1] || props.outputType })
}

function outputCanvasSize(coordinates: CropCoordinates) {
  return calculateCropCanvasSize(coordinates, {
    width: props.outputWidth,
    height: props.outputHeight
  })
}

function transformedSourceCanvas(cropper: Cropper, image: HTMLImageElement) {
  const imageData = cropper.getImageData()
  const canvasData = cropper.getCanvasData()
  const canvas = document.createElement('canvas')
  canvas.width = Math.max(1, Math.round(canvasData.naturalWidth))
  canvas.height = Math.max(1, Math.round(canvasData.naturalHeight))
  const context = canvas.getContext('2d')
  if (!context) throw new Error('当前浏览器不支持图片处理')

  context.translate(canvas.width / 2, canvas.height / 2)
  context.rotate(((imageData.rotate || 0) * Math.PI) / 180)
  context.scale(imageData.scaleX || 1, imageData.scaleY || 1)
  context.imageSmoothingEnabled = true
  context.imageSmoothingQuality = 'high'
  context.drawImage(
    image,
    -imageData.naturalWidth / 2,
    -imageData.naturalHeight / 2,
    imageData.naturalWidth,
    imageData.naturalHeight
  )
  return canvas
}

function cropCanvas(cropper: Cropper, coordinates: CropCoordinates) {
  if (!sourceImage) throw new Error('原图尚未准备好')
  const imageData = cropper.getImageData()
  const hasTransform = Boolean(imageData.rotate || imageData.scaleX !== 1 || imageData.scaleY !== 1)
  const source = hasTransform ? transformedSourceCanvas(cropper, sourceImage) : sourceImage
  const size = outputCanvasSize(coordinates)
  const canvas = document.createElement('canvas')
  canvas.width = size.width
  canvas.height = size.height
  const context = canvas.getContext('2d')
  if (!context) throw new Error('当前浏览器不支持图片处理')

  if (props.outputType === 'image/jpeg') {
    context.fillStyle = '#fff'
    context.fillRect(0, 0, canvas.width, canvas.height)
  }
  context.imageSmoothingEnabled = true
  context.imageSmoothingQuality = 'high'
  const scaleX = canvas.width / coordinates.width
  const scaleY = canvas.height / coordinates.height
  context.drawImage(
    source,
    -coordinates.left * scaleX,
    -coordinates.top * scaleY,
    source.width * scaleX,
    source.height * scaleY
  )

  if (props.shape === 'circle') {
    context.globalCompositeOperation = 'destination-in'
    context.beginPath()
    context.arc(canvas.width / 2, canvas.height / 2, Math.min(canvas.width, canvas.height) / 2, 0, Math.PI * 2)
    context.fill()
  }
  return canvas
}

function resetCrop() {
  getCropper()?.reset()
  zoomPercent.value = 100
}

function rotateCrop(degree: number) {
  getCropper()?.rotate(degree)
}

function flipCrop(axis: 'horizontal' | 'vertical') {
  const cropper = getCropper()
  if (!cropper) return
  const image = cropper.getImageData()
  if (axis === 'horizontal') {
    cropper.scaleX(-(image.scaleX || 1))
    return
  }
  cropper.scaleY(-(image.scaleY || 1))
}

function setZoomPercent(value: number | number[]) {
  const requested = Array.isArray(value) ? value[0] : value
  if (requested === undefined || !Number.isFinite(requested)) return
  const nextPercent = Math.min(ZOOM_MAX, Math.max(ZOOM_MIN, Math.round(requested)))
  getCropper()?.zoomTo(baseCanvasRatio * (nextPercent / 100))
}

function handleZoomInput(event: Event) {
  setZoomPercent(Number((event.target as HTMLInputElement).value))
}

function adjustZoom(direction: -1 | 1) {
  setZoomPercent(zoomPercent.value + direction * ZOOM_STEP)
}

async function confirmCrop() {
  const cropper = getCropper()
  if (!cropper || !props.file || !sourceSize.value) return

  const coordinates = cropCoordinates(cropper)
  const message = validateCrop(coordinates)
  if (message) {
    localError.value = message
    emit('error', message)
    return
  }

  processing.value = true
  try {
    const canvas = cropCanvas(cropper, coordinates)
    const blob = blobFromCanvas(canvas)
    if (!blob) throw new Error('图片导出失败')
    const fileName = filenameForCrop(props.file.name, props.outputType)
    emit('cropped', {
      file: new File([blob], fileName, { type: props.outputType }),
      blob,
      coordinates,
      source: sourceSize.value,
      outputSize: { width: canvas.width, height: canvas.height }
    })
    localOpen.value = false
  } catch (err) {
    const error = (err as Error).message || '图片裁剪失败'
    localError.value = error
    emit('error', error)
  } finally {
    processing.value = false
  }
}

function cancelCrop() {
  localOpen.value = false
  emit('cancel')
}

watch(() => [props.open, props.file] as const, ([open, file]) => {
  if (open) prepareFile(file)
  else {
    cleanupObjectUrl()
    sourceSize.value = null
    localError.value = ''
    loading.value = false
  }
}, { immediate: true })

onBeforeUnmount(cleanupObjectUrl)
</script>

<template>
  <UModal v-model:open="localOpen" :title="title" :ui="{ content: 'max-w-6xl overflow-hidden' }">
    <template #body>
      <div
        class="asset-image-cropper-layout max-h-[calc(100vh-12rem)] overflow-x-hidden overflow-y-auto"
        data-asset-image-cropper
        :data-has-instance="Boolean(getCropper())"
        :data-ready="cropperReady"
        :data-loading="loading"
        :data-processing="processing"
        :data-can-confirm="canConfirm"
      >
        <div class="min-w-0 space-y-3">
          <div class="overflow-hidden rounded-lg border border-default bg-elevated p-2">
            <div class="asset-image-cropper-stage relative h-[clamp(20rem,56vh,32rem)] min-h-80 overflow-hidden rounded-md">
              <ClientOnly>
                <img
                  v-if="imageUrl"
                  :key="cropperKey"
                  ref="imageElement"
                  :src="imageUrl"
                  alt=""
                  class="block max-w-full"
                  @load="initializeCropper"
                >
                <div v-else class="grid size-full place-items-center text-sm text-muted">
                  {{ loading ? '正在加载图片' : '请选择图片' }}
                </div>
              </ClientOnly>

            </div>

            <div class="asset-image-cropper-toolbar-row">
              <span class="size-8" aria-hidden="true" />
              <div class="asset-image-cropper-toolbar" role="toolbar" aria-label="图片变换工具">
                <UTooltip text="缩小">
                  <UButton icon="i-tabler-minus" color="neutral" variant="ghost" size="sm" square aria-label="缩小" :disabled="zoomPercent <= ZOOM_MIN" @click="adjustZoom(-1)" />
                </UTooltip>
                <div class="asset-image-cropper-zoom">
                  <input
                    class="asset-image-cropper-zoom-range"
                    type="range"
                    :value="zoomPercent"
                    :min="ZOOM_MIN"
                    :max="ZOOM_MAX"
                    :step="ZOOM_STEP"
                    aria-label="缩放比例"
                    @input="handleZoomInput"
                  >
                  <output class="text-center text-xs tabular-nums text-default" aria-live="polite">{{ zoomPercent }}%</output>
                </div>
                <UTooltip text="放大">
                  <UButton icon="i-tabler-plus" color="neutral" variant="ghost" size="sm" square aria-label="放大" :disabled="zoomPercent >= ZOOM_MAX" @click="adjustZoom(1)" />
                </UTooltip>
                <span class="mx-1 h-5 w-px bg-accented" aria-hidden="true" />
                <UTooltip text="向左旋转">
                  <UButton icon="i-tabler-rotate-2" color="neutral" variant="ghost" size="sm" square aria-label="向左旋转" @click="rotateCrop(-90)" />
                </UTooltip>
                <UTooltip text="向右旋转">
                  <UButton icon="i-tabler-rotate-clockwise" color="neutral" variant="ghost" size="sm" square aria-label="向右旋转" @click="rotateCrop(90)" />
                </UTooltip>
                <span class="mx-1 h-5 w-px bg-accented" aria-hidden="true" />
                <UTooltip text="水平翻转">
                  <UButton icon="i-tabler-flip-horizontal" color="neutral" variant="ghost" size="sm" square aria-label="水平翻转" @click="flipCrop('horizontal')" />
                </UTooltip>
                <UTooltip text="垂直翻转">
                  <UButton icon="i-tabler-flip-vertical" color="neutral" variant="ghost" size="sm" square aria-label="垂直翻转" @click="flipCrop('vertical')" />
                </UTooltip>
                <UTooltip text="重置">
                  <UButton icon="i-tabler-focus-centered" color="neutral" variant="ghost" size="sm" square aria-label="重置" @click="resetCrop" />
                </UTooltip>
              </div>
              <UTooltip text="拖动图片调整位置；滚轮或工具栏缩放；拖动裁剪框调整范围。">
                <UButton icon="i-tabler-help-circle" color="neutral" variant="ghost" size="sm" square aria-label="图片编辑帮助" />
              </UTooltip>
            </div>
          </div>

          <UAlert
            v-if="localError"
            color="error"
            variant="soft"
            icon="i-tabler-alert-circle"
            :title="localError"
          />
        </div>

        <aside class="min-w-0 space-y-4">
          <slot name="controls" :source-size="sourceSize" :output-size="currentOutputSize" />

        </aside>
      </div>
    </template>

    <template #footer>
      <div class="flex w-full justify-end gap-2">
        <UButton color="neutral" variant="ghost" label="取消" :disabled="processing" @click="cancelCrop" />
        <UButton icon="i-tabler-crop" :label="confirmLabel" :loading="processing" :disabled="!canConfirm" @click="confirmCrop" />
      </div>
    </template>
  </UModal>
</template>

<style scoped>
.asset-image-cropper-layout {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  gap: 1rem;
}

@media (min-width: 1024px) {
  .asset-image-cropper-layout {
    grid-template-columns: minmax(0, 1fr) 18rem;
  }
}

.asset-image-cropper-stage {
  height: clamp(20rem, 56vh, 32rem);
  min-height: 20rem;
  background-color: #f8fafc;
  background-image:
    linear-gradient(45deg, #eef2f7 25%, transparent 25%),
    linear-gradient(-45deg, #eef2f7 25%, transparent 25%),
    linear-gradient(45deg, transparent 75%, #eef2f7 75%),
    linear-gradient(-45deg, transparent 75%, #eef2f7 75%);
  background-position:
    0 0,
    0 14px,
    14px -14px,
    -14px 0;
  background-size: 28px 28px;
}

.asset-image-cropper-toolbar {
  display: flex;
  max-width: 100%;
  align-items: center;
  gap: 0.125rem;
  padding: 0.25rem;
  border: 1px solid var(--ui-border);
  border-radius: 0.75rem;
  background: var(--ui-bg);
  overflow-x: auto;
}

.asset-image-cropper-toolbar-row {
  display: grid;
  grid-template-columns: 2rem minmax(0, auto) 2rem;
  align-items: center;
  justify-content: space-between;
  gap: 0.5rem;
  padding: 0.5rem 0.25rem 0;
}

.asset-image-cropper-zoom {
  display: grid;
  width: 8rem;
  grid-template-columns: minmax(0, 1fr) 2.5rem;
  align-items: center;
  gap: 0.5rem;
  padding-inline: 0.25rem;
}

.asset-image-cropper-zoom-range {
  width: 100%;
  height: 1rem;
  cursor: pointer;
  accent-color: var(--ui-primary);
}

.asset-image-cropper-zoom-range:focus-visible {
  border-radius: 0.25rem;
  outline: 3px solid color-mix(in oklab, var(--ui-primary) 25%, transparent);
  outline-offset: 2px;
}

:deep(.cropper-container) {
  width: 100% !important;
  height: 100% !important;
}

:deep(.cropper-wrap-box),
:deep(.cropper-drag-box) {
  width: 100% !important;
  height: 100% !important;
}

:deep(.cropper-view-box),
:deep(.cropper-face) {
  outline-color: rgba(255, 255, 255, 0.95);
}

:deep(.cropper-line),
:deep(.cropper-point) {
  background-color: var(--ui-primary);
}
</style>
