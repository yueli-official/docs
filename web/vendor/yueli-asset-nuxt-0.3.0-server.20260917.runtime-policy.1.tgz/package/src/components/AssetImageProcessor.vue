<script setup lang="ts">
import AssetImageCropper from './AssetImageCropper.vue'
import type { AssetCropOutputType } from '../image-cropper'
import { preserveImageTimeline } from '../animated-image'
import type { AssetImageTransferState } from '../upload'

export type AssetImagePurpose = 'cover' | 'content'

interface ProcessedImagePayload {
  file: File
  blob: Blob
  coordinates: { left: number, top: number, width: number, height: number }
  source: { width: number, height: number }
  output: {
    format: AssetCropOutputType
    quality: number
    aspectRatio: number | null
    width: number
    height: number
    maxSide: number | null
  }
}

const props = withDefaults(defineProps<{
  open?: boolean
  file?: File | null
  purpose?: AssetImagePurpose
  title?: string
  initialAspectRatio?: number
  initialAspectRatioLabel?: string
  fixedMaxOutputSide?: number
  fixedMaxOutputWidth?: number
  fixedOutputType?: AssetCropOutputType
  transfer?: AssetImageTransferState | null
}>(), {
  open: false,
  file: null,
  purpose: 'content',
  title: '处理图片',
  initialAspectRatio: undefined,
  initialAspectRatioLabel: undefined,
  fixedMaxOutputSide: undefined,
  fixedMaxOutputWidth: undefined,
  fixedOutputType: undefined
})

const emit = defineEmits<{
  'update:open': [value: boolean]
  processed: [payload: ProcessedImagePayload | { file: File, blob: Blob, preservedAnimation: true }]
  cancel: []
  error: [message: string]
  retry: []
}>()

type RatioChoice = 'free' | 'configured' | '3:2' | '16:9' | '4:3' | '1:1' | 'custom'

const ratio = ref<RatioChoice>('free')
const customRatioWidth = ref(3)
const customRatioHeight = ref(2)
const outputType = ref<AssetCropOutputType>('image/webp')
const qualityPercent = ref(88)
const maxOutputSide = ref(1920)
const preserveTimeline = ref(false)
const inspecting = ref(false)
const animationPreview = ref('')
let inspectionGeneration = 0
function releasePreview() {
  if (animationPreview.value) URL.revokeObjectURL(animationPreview.value)
  animationPreview.value = ''
}
watch(() => [props.open, props.file] as const, async ([open, file]) => {
  const generation = ++inspectionGeneration
  releasePreview()
  preserveTimeline.value = false
  inspecting.value = !!open && !!file
  if (!open || !file) return
  try {
    const preserve = await preserveImageTimeline(file)
    if (generation !== inspectionGeneration) return
    preserveTimeline.value = preserve
    if (preserve) animationPreview.value = URL.createObjectURL(file)
  } catch {
    if (generation !== inspectionGeneration) return
    emit('error', '无法读取图片，请重新选择。')
    emit('update:open', false)
  } finally {
    if (generation === inspectionGeneration) inspecting.value = false
  }
}, { immediate: true })
onBeforeUnmount(() => { inspectionGeneration++; releasePreview() })
function confirmAnimation() {
  if (!props.file || inspecting.value || !preserveTimeline.value) return
  emit('processed', { file: props.file, blob: props.file, preservedAnimation: true })
  emit('update:open', false)
}

const presetRatios = [
  { label: '横向 3:2', value: '3:2' as const, ratio: 3 / 2 },
  { label: '宽屏 16:9', value: '16:9' as const, ratio: 16 / 9 },
  { label: '标准 4:3', value: '4:3' as const, ratio: 4 / 3 },
  { label: '方形 1:1', value: '1:1' as const, ratio: 1 }
]
const formatItems = [
  { label: 'WebP · 推荐', value: 'image/webp' },
  { label: 'JPEG · 通用', value: 'image/jpeg' },
  { label: 'PNG · 保留透明', value: 'image/png' }
]
const outputSizeItems = [
  { label: '原始裁剪尺寸', value: 0 },
  { label: '最长边 1920px', value: 1920 },
  { label: '最长边 1600px', value: 1600 },
  { label: '最长边 1280px', value: 1280 },
  { label: '最长边 1200px', value: 1200 },
  { label: '最长边 960px', value: 960 },
  { label: '最长边 640px', value: 640 }
]

const configuredAspectRatio = computed(() => {
  const value = Number(props.initialAspectRatio)
  return Number.isFinite(value) && value > 0 ? value : undefined
})
const ratioItems = computed(() => {
  const items: Array<{ label: string, value: RatioChoice }> = []
  if (props.purpose === 'content') items.push({ label: '自由裁剪', value: 'free' })
  if (configuredAspectRatio.value) {
    items.push({
      label: `站点默认 · ${props.initialAspectRatioLabel || configuredAspectRatio.value.toFixed(2)}`,
      value: 'configured'
    })
  }
  for (const preset of presetRatios) {
    if (configuredAspectRatio.value && Math.abs(configuredAspectRatio.value - preset.ratio) < 0.0001) continue
    items.push({ label: preset.label, value: preset.value })
  }
  items.push({ label: '自定义比例', value: 'custom' })
  return items
})
const aspectRatio = computed(() => {
  if (ratio.value === 'free') return undefined
  if (ratio.value === 'configured') return configuredAspectRatio.value || 3 / 2
  if (ratio.value === 'custom') {
    const width = Number(customRatioWidth.value)
    const height = Number(customRatioHeight.value)
    return Number.isFinite(width) && Number.isFinite(height) && width > 0 && height > 0
      ? width / height
      : 3 / 2
  }
  return presetRatios.find(preset => preset.value === ratio.value)?.ratio || 3 / 2
})
const cropMode = computed(() => ratio.value === 'free' ? 'free' : 'fixed-aspect')
const outputWidth = computed(() => props.fixedMaxOutputWidth || maxOutputSide.value || undefined)
const outputHeight = computed(() => props.fixedMaxOutputWidth ? undefined : maxOutputSide.value || undefined)
const quality = computed(() => outputType.value === 'image/png' ? 1 : qualityPercent.value / 100)
const inputSize = computed(() => props.file ? formatBytes(props.file.size) : '')
const formatHelp = computed(() => {
  const format = outputType.value === 'image/jpeg'
    ? 'JPEG 会用白色填充透明区域。'
    : outputType.value === 'image/webp'
      ? 'WebP 通常体积更小，并支持透明区域。'
      : 'PNG 支持透明区域，但文件通常更大。'
  return `${format}处理结果仍按资源中心限制校验。`
})

function formatBytes(bytes: number) {
  if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))} KB`
  return `${(bytes / 1024 / 1024).toFixed(bytes >= 10 * 1024 * 1024 ? 0 : 1)} MB`
}

function resetOptions() {
  ratio.value = props.purpose === 'cover'
    ? configuredAspectRatio.value ? 'configured' : '3:2'
    : 'free'
  customRatioWidth.value = 3
  customRatioHeight.value = 2
  outputType.value = props.fixedOutputType || 'image/webp'
  qualityPercent.value = 88
  maxOutputSide.value = props.fixedMaxOutputSide || (props.purpose === 'cover' ? 1600 : 1920)
}

function onProcessed(payload: Omit<ProcessedImagePayload, 'output'> & { outputSize: { width: number, height: number } }) {
  const { outputSize, ...processed } = payload
  emit('processed', {
    ...processed,
    output: {
      format: outputType.value,
      quality: quality.value,
      aspectRatio: aspectRatio.value ?? null,
      width: outputSize.width,
      height: outputSize.height,
      maxSide: props.fixedMaxOutputWidth ? null : maxOutputSide.value || null
    }
  })
}

watch(() => [props.open, props.file, props.purpose, props.initialAspectRatio] as const, ([open]) => {
  if (open) resetOptions()
})
</script>

<template>
  <AssetImageCropper
    v-if="!inspecting && !preserveTimeline && !transfer"
    :open="open"
    :file="file"
    :title="title"
    shape="rect"
    :mode="cropMode"
    :aspect-ratio="aspectRatio"
    :output-width="outputWidth"
    :output-height="outputHeight"
    :output-type="outputType"
    :quality="quality"
    confirm-label="使用处理后的图片"
    @update:open="emit('update:open', $event)"
    @cropped="onProcessed"
    @cancel="emit('cancel')"
    @error="emit('error', $event)"
  >
    <template #controls="{ outputSize, sourceSize }">
      <div class="space-y-5" data-asset-image-processor-controls>
        <section class="space-y-4" aria-labelledby="asset-image-crop-heading">
          <h3 id="asset-image-crop-heading" class="text-sm font-semibold text-highlighted">裁剪</h3>

          <UFormField label="比例">
            <USelect v-model="ratio" :items="ratioItems" value-key="value" class="w-full" />
          </UFormField>

          <div
            v-if="ratio === 'custom'"
            class="grid grid-cols-[1fr_auto_1fr] items-end gap-2"
            data-asset-image-custom-ratio
          >
            <UFormField label="宽度">
              <UInputNumber v-model="customRatioWidth" :min="1" :max="100" class="w-full" />
            </UFormField>
            <span class="pb-1.5 text-sm text-muted">:</span>
            <UFormField label="高度">
              <UInputNumber v-model="customRatioHeight" :min="1" :max="100" class="w-full" />
            </UFormField>
          </div>
        </section>

        <section class="space-y-4 border-t border-muted pt-5" aria-labelledby="asset-image-export-heading">
          <h3 id="asset-image-export-heading" class="text-sm font-semibold text-highlighted">导出</h3>

          <UFormField label="尺寸">
            <template #hint>
              <span v-if="outputSize" class="tabular-nums">{{ outputSize.width }} × {{ outputSize.height }}</span>
            </template>
            <div v-if="fixedMaxOutputWidth" class="rounded-md border border-default bg-default px-3 py-1.5 text-sm text-default" data-asset-image-fixed-width>
              最大宽度 {{ fixedMaxOutputWidth }}px
            </div>
            <div v-else-if="fixedMaxOutputSide" class="rounded-md border border-default bg-default px-3 py-1.5 text-sm text-default" data-asset-image-fixed-size>
              最长边 {{ fixedMaxOutputSide }}px
            </div>
            <USelect v-else v-model="maxOutputSide" :items="outputSizeItems" value-key="value" class="w-full" />
          </UFormField>

          <UFormField label="格式">
            <template #hint>
              <UTooltip :text="formatHelp">
                <UButton icon="i-tabler-help-circle" color="neutral" variant="ghost" size="xs" square aria-label="输出格式说明" />
              </UTooltip>
            </template>
            <div v-if="fixedOutputType" class="rounded-md border border-default bg-default px-3 py-1.5 text-sm text-default" data-asset-image-fixed-format>
              {{ formatItems.find(item => item.value === fixedOutputType)?.label || fixedOutputType }}
            </div>
            <USelect v-else v-model="outputType" :items="formatItems" value-key="value" class="w-full" />
          </UFormField>

          <UFormField v-if="outputType !== 'image/png'" label="质量" :hint="`${qualityPercent}%`">
            <USlider v-model="qualityPercent" :min="60" :max="96" :step="1" />
          </UFormField>
        </section>

        <div
          class="flex items-center gap-2 border-t border-muted pt-3 text-xs text-muted"
          data-asset-image-file-info
        >
          <span class="min-w-0 flex-1 truncate" :title="file?.name">{{ file?.name }}</span>
          <span class="shrink-0 tabular-nums">{{ sourceSize?.width }} × {{ sourceSize?.height }} · {{ inputSize }}</span>
        </div>
      </div>
    </template>
  </AssetImageCropper>
  <UModal v-else :open="open" :title="title" :close="!transfer || transfer.stage === 'error'" :dismissible="!transfer || transfer.stage === 'error'" description="图片就绪后会自动插入编辑器。" @update:open="emit('update:open', $event)">
    <template #body>
      <div v-if="transfer" class="space-y-4" data-asset-image-transfer :data-stage="transfer.stage" :aria-busy="transfer.stage !== 'error'">
        <p :role="transfer.stage === 'error' ? 'alert' : 'status'" class="text-sm leading-6">
          {{ transfer.stage === 'uploading' ? '正在上传图片' : transfer.stage === 'finalizing' ? '正在保存图片' : transfer.stage === 'preparing' ? '正在生成并加载图片' : '图片处理未完成' }}
          <span v-if="transfer.stage === 'uploading' && transfer.progress != null"> · {{ transfer.progress }}%</span>
        </p>
        <div v-if="transfer.stage !== 'error'" class="asset-transfer-track" role="progressbar" aria-label="图片上传与处理进度" :aria-valuenow="transfer.stage === 'uploading' ? transfer.progress : undefined" :aria-valuemin="0" :aria-valuemax="100">
          <span v-if="transfer.stage === 'uploading' && transfer.progress != null" class="asset-transfer-value" :style="{ transform: `scaleX(${transfer.progress / 100})` }" />
          <span v-else class="asset-transfer-sweep" />
        </div>
        <p class="text-sm leading-6 text-muted">{{ transfer.message || '大图和动态图首次处理需要一些时间。完成后自动插入，无需重复上传。' }}</p>
      </div>
      <p v-else-if="inspecting" role="status" class="text-sm text-muted">正在检查图片格式…</p>
      <div v-else class="space-y-4" data-asset-animation-processor>
        <img :src="animationPreview" alt="动态图预览" class="mx-auto max-h-80 max-w-full object-contain" />
        <p class="text-sm leading-6 text-muted">GIF／动态图将保留原始帧上传，由资源服务生成动态 WebP。为避免丢帧，不使用静态裁剪和旋转；尺寸按站点图片策略处理。</p>
        <p class="break-all text-xs text-muted">{{ file?.name }} · {{ inputSize }}</p>
      </div>
    </template>
    <template #footer>
      <template v-if="transfer">
        <UButton v-if="transfer.stage === 'error'" label="关闭" color="neutral" variant="ghost" @click="emit('cancel'); emit('update:open', false)" />
        <UButton v-if="transfer.stage === 'error'" label="重试" @click="emit('retry')" />
        <UButton v-else label="处理中" loading disabled />
      </template>
      <template v-else>
        <UButton label="取消" color="neutral" variant="ghost" @click="emit('cancel'); emit('update:open', false)" />
        <UButton label="保留动画并上传" :disabled="inspecting" @click="confirmAnimation" />
      </template>
    </template>
  </UModal>
</template>

<style scoped>
.asset-transfer-track { position: relative; height: .5rem; overflow: hidden; border-radius: .25rem; background: var(--ui-bg-accented); }
.asset-transfer-value { display: block; height: 100%; background: var(--ui-primary); transform-origin: left; transition: transform 150ms ease; }
.asset-transfer-sweep { display: block; height: 100%; width: 35%; background: var(--ui-primary); animation: asset-transfer-sweep 1.2s ease-in-out infinite; }
@keyframes asset-transfer-sweep { from { transform: translateX(-100%); } to { transform: translateX(300%); } }
@media (prefers-reduced-motion: reduce) { .asset-transfer-sweep { animation: none; margin-inline: auto; opacity: .65; } .asset-transfer-value { transition: none; } }
</style>
