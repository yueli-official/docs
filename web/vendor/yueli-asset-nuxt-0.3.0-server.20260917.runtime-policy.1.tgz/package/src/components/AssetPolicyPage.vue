<script setup lang="ts">
import type { AssetVariantSlotDefinition } from "../registration";
import AssetRegistrationSummary from "./AssetRegistrationSummary.client.vue";

withDefaults(
  defineProps<{
    expectedNamespace: string;
    profileOrder?: string[];
    canEdit?: boolean;
    variantSlots?: AssetVariantSlotDefinition[];
    id?: string;
    title?: string;
    icon?: string;
  }>(),
  {
    profileOrder: () => [],
    canEdit: false,
    variantSlots: () => [],
    id: "assets",
    title: "资源策略",
    icon: "i-tabler-database-cog",
  },
);
</script>

<template>
  <YManagePage :id="id" :title="title" :icon="icon">
    <ClientOnly>
      <AssetRegistrationSummary
        :expected-namespace="expectedNamespace"
        :profile-order="profileOrder"
        :can-edit="canEdit"
        :variant-slots="variantSlots"
      />
      <template #fallback>
        <div class="space-y-3" aria-label="正在加载资源策略">
          <USkeleton class="h-28 w-full rounded-xl" />
          <USkeleton class="h-56 w-full rounded-xl" />
        </div>
      </template>
    </ClientOnly>
  </YManagePage>
</template>
