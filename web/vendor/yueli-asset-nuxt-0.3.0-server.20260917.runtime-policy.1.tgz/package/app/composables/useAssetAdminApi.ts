import { toAssetAdminProxyPath } from "../../src/api";
import {
  useAssetRuntimeApi,
  type AssetApiCallOptions,
} from "../utils/api";

export function useAssetAdminApi() {
  const api = useAssetRuntimeApi("identity");
  return {
    ...api,
    call: <T>(
      url: string,
      opts?: AssetApiCallOptions,
    ) => api.call<T>(toAssetAdminProxyPath(url), opts),
  };
}
