import { useAssetRuntimeApi } from "../utils/api";

export function useAssetApi() {
  return useAssetRuntimeApi("asset");
}
